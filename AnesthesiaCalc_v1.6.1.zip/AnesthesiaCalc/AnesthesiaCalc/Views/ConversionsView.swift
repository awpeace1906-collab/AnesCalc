// AnesthesiaCalc v1.6.0
// New File: ConversionsView.swift
// Change: Conversions tab — US Customary ↔ Metric and concentration unit converter

import SwiftUI

// MARK: - Concentration units

enum MassUnit: String, CaseIterable, Identifiable {
    case mcg = "mcg"
    case mg  = "mg"
    case g   = "g"
    var id: String { rawValue }
    var toGrams: Double {
        switch self {
        case .mcg: return 1e-6
        case .mg:  return 1e-3
        case .g:   return 1.0
        }
    }
}

enum VolumeUnit: String, CaseIterable, Identifiable {
    case mL  = "mL"
    case dL  = "dL"
    case L   = "L"
    var id: String { rawValue }
    var toML: Double {
        switch self {
        case .mL: return 1.0
        case .dL: return 100.0
        case .L:  return 1000.0
        }
    }
}

// MARK: - Main View

struct ConversionsView: View {
    @EnvironmentObject var theme: ThemeManager

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    MeasurementConverterCard()
                    ConcentrationConverterCard()
                    TemperatureConverterCard()
                    WeightConverterCard()
                    PressureConverterCard()
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 12)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Conversions")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackground(theme.headerBg)
        }
        .navigationViewStyle(.stack)
    }
}

// MARK: - Measurement (Height) Converter

struct MeasurementConverterCard: View {
    @EnvironmentObject var theme: ThemeManager

    // ft + in → cm
    @State private var feet: Double = 5
    @State private var inches: Double = 10
    @State private var cm: Double = 177.8

    // ft → m
    @State private var feetOnly: Double = 5
    @State private var meters: Double = 1.524

    @State private var editingCm = false
    @State private var editingFtIn = false

    var body: some View {
        converterCard(title: "Height / Length", icon: "ruler", colorKey: "section2") {
            VStack(spacing: 12) {

                // ── Feet + Inches ↔ Centimeters ────────────────────────────
                sectionHeader("Feet & Inches  ↔  Centimeters")

                HStack(spacing: 10) {
                    // Feet
                    unitField("Feet", value: $feet, format: "%.0f") {
                        let totalIn = feet * 12 + inches
                        cm = totalIn * 2.54
                    }
                    Text("+").foregroundColor(.secondary).font(.title3)
                    // Inches
                    unitField("Inches", value: $inches, format: "%.1f") {
                        let totalIn = feet * 12 + inches
                        cm = totalIn * 2.54
                    }
                    arrowLabel("=")
                    // cm result
                    unitField("cm", value: $cm, format: "%.1f") {
                        let totalIn = cm / 2.54
                        feet = floor(totalIn / 12)
                        inches = totalIn.truncatingRemainder(dividingBy: 12)
                    }
                }

                Divider()

                // ── Feet ↔ Meters ────────────────────────────────────────
                sectionHeader("Feet  ↔  Meters")

                HStack(spacing: 10) {
                    unitField("Feet", value: $feetOnly, format: "%.2f") {
                        meters = feetOnly * 0.3048
                    }
                    arrowLabel("=")
                    unitField("Meters", value: $meters, format: "%.3f") {
                        feetOnly = meters / 0.3048
                    }
                }
            }
        }
    }
}

// MARK: - Concentration Converter

struct ConcentrationConverterCard: View {
    @EnvironmentObject var theme: ThemeManager

    @State private var numeratorValue: Double = 1.0
    @State private var numeratorMass: MassUnit = .mg
    @State private var denominatorValue: Double = 1.0
    @State private var denominatorVol: VolumeUnit = .mL

    @State private var resultNumeratorValue: Double = 0.0
    @State private var resultNumeratorMass: MassUnit = .g
    @State private var resultDenominatorValue: Double = 1.0
    @State private var resultDenominatorVol: VolumeUnit = .dL

    var body: some View {
        converterCard(title: "Concentration", icon: "drop.halffull", colorKey: "section8") {
            VStack(spacing: 14) {

                sectionHeader("Enter concentration on left, select output units on right")

                // ── Input side ────────────────────────────────────────────
                HStack(alignment: .center, spacing: 6) {
                    // Numerator
                    VStack(spacing: 4) {
                        TextField("", value: $numeratorValue, format: .number)
                            .keyboardType(.decimalPad)
                            .multilineTextAlignment(.center)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(theme.sectionColor("section8"))
                            .frame(width: 70)
                            .padding(6)
                            .background(Color(.systemBackground))
                            .cornerRadius(6)
                            .overlay(RoundedRectangle(cornerRadius: 6)
                                .stroke(theme.sectionColor("section8").opacity(0.3), lineWidth: 1))

                        Picker("", selection: $numeratorMass) {
                            ForEach(MassUnit.allCases) { u in Text(u.rawValue).tag(u) }
                        }
                        .pickerStyle(.menu)
                        .frame(width: 80)
                        .padding(4)
                        .background(Color(.systemBackground))
                        .cornerRadius(6)
                        .overlay(RoundedRectangle(cornerRadius: 6)
                            .stroke(theme.sectionColor("section8").opacity(0.25), lineWidth: 1))
                    }

                    Text("/").font(.title2.bold()).foregroundColor(.secondary)

                    VStack(spacing: 4) {
                        TextField("", value: $denominatorValue, format: .number)
                            .keyboardType(.decimalPad)
                            .multilineTextAlignment(.center)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(theme.sectionColor("section8"))
                            .frame(width: 70)
                            .padding(6)
                            .background(Color(.systemBackground))
                            .cornerRadius(6)
                            .overlay(RoundedRectangle(cornerRadius: 6)
                                .stroke(theme.sectionColor("section8").opacity(0.3), lineWidth: 1))

                        Picker("", selection: $denominatorVol) {
                            ForEach(VolumeUnit.allCases) { u in Text(u.rawValue).tag(u) }
                        }
                        .pickerStyle(.menu)
                        .frame(width: 80)
                        .padding(4)
                        .background(Color(.systemBackground))
                        .cornerRadius(6)
                        .overlay(RoundedRectangle(cornerRadius: 6)
                            .stroke(theme.sectionColor("section8").opacity(0.25), lineWidth: 1))
                    }

                    arrowLabel("=")

                    // ── Output side ───────────────────────────────────────
                    VStack(spacing: 4) {
                        let result = convertConcentration()
                        Text(formatConc(result))
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(theme.sectionColor("section8"))
                            .frame(width: 80)
                            .padding(6)
                            .background(Color(.systemBackground))
                            .cornerRadius(6)
                            .overlay(RoundedRectangle(cornerRadius: 6)
                                .stroke(theme.sectionColor("section8").opacity(0.3), lineWidth: 1))

                        Picker("", selection: $resultNumeratorMass) {
                            ForEach(MassUnit.allCases) { u in Text(u.rawValue).tag(u) }
                        }
                        .pickerStyle(.menu)
                        .frame(width: 80)
                        .padding(4)
                        .background(Color(.systemBackground))
                        .cornerRadius(6)
                        .overlay(RoundedRectangle(cornerRadius: 6)
                            .stroke(theme.sectionColor("section8").opacity(0.25), lineWidth: 1))
                    }

                    Text("/").font(.title2.bold()).foregroundColor(.secondary)

                    VStack(spacing: 4) {
                        Text("1")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(.secondary)
                            .frame(width: 50)
                            .padding(6)
                            .background(Color(.systemBackground))
                            .cornerRadius(6)

                        Picker("", selection: $resultDenominatorVol) {
                            ForEach(VolumeUnit.allCases) { u in Text(u.rawValue).tag(u) }
                        }
                        .pickerStyle(.menu)
                        .frame(width: 80)
                        .padding(4)
                        .background(Color(.systemBackground))
                        .cornerRadius(6)
                        .overlay(RoundedRectangle(cornerRadius: 6)
                            .stroke(theme.sectionColor("section8").opacity(0.25), lineWidth: 1))
                    }
                }

                // Common conversions quick reference
                Divider()
                sectionHeader("Quick reference")
                VStack(alignment: .leading, spacing: 4) {
                    quickRef("1%  =  10 mg/mL  =  0.01 g/mL")
                    quickRef("0.5%  =  5 mg/mL")
                    quickRef("0.25%  =  2.5 mg/mL")
                    quickRef("0.1%  =  1 mg/mL")
                    quickRef("1 g/dL  =  10 mg/mL")
                    quickRef("1 mg/mL  =  1000 mcg/mL")
                }
            }
        }
    }

    func convertConcentration() -> Double {
        // Input: numeratorValue [numeratorMass] per denominatorValue [denominatorVol]
        // = X [resultNumeratorMass] per 1 [resultDenominatorVol]
        guard denominatorValue > 0 else { return 0 }
        let massInGrams = numeratorValue * numeratorMass.toGrams
        let volInML     = denominatorValue * denominatorVol.toML
        let gPerML      = massInGrams / volInML
        // Convert to result units: resultNumeratorMass per 1 resultDenominatorVol
        let resultMassUnits = gPerML / resultNumeratorMass.toGrams
        let resultPerUnit   = resultMassUnits * resultDenominatorVol.toML
        return resultPerUnit
    }

    func formatConc(_ v: Double) -> String {
        if v == 0 { return "0" }
        if v >= 1000 { return String(format: "%.0f", v) }
        if v >= 10   { return String(format: "%.1f", v) }
        if v >= 1    { return String(format: "%.2f", v) }
        return String(format: "%.4f", v)
    }

    func quickRef(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 11, design: .monospaced))
            .foregroundColor(.secondary)
    }
}

// MARK: - Temperature Converter

struct TemperatureConverterCard: View {
    @EnvironmentObject var theme: ThemeManager
    @State private var celsius: Double = 37.0
    @State private var fahrenheit: Double = 98.6

    var body: some View {
        converterCard(title: "Temperature", icon: "thermometer.medium", colorKey: "section12") {
            HStack(spacing: 10) {
                unitField("°C", value: $celsius, format: "%.1f") {
                    fahrenheit = celsius * 9/5 + 32
                }
                arrowLabel("↔")
                unitField("°F", value: $fahrenheit, format: "%.1f") {
                    celsius = (fahrenheit - 32) * 5/9
                }
            }
            // Common clinical reference
            HStack(spacing: 16) {
                tempRef("Hypothermia", "< 35°C / 95°F")
                tempRef("Normal", "36.5–37.5°C")
                tempRef("Fever", "> 38°C / 100.4°F")
            }
            .padding(.top, 8)
        }
    }

    func tempRef(_ label: String, _ value: String) -> some View {
        VStack(spacing: 2) {
            Text(label).font(.system(size: 9)).foregroundColor(.secondary)
            Text(value).font(.system(size: 10, weight: .medium)).foregroundColor(.primary)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Weight Converter

struct WeightConverterCard: View {
    @EnvironmentObject var theme: ThemeManager
    @State private var kg: Double = 70.0
    @State private var lbs: Double = 154.3

    var body: some View {
        converterCard(title: "Weight", icon: "scalemass", colorKey: "section1") {
            HStack(spacing: 10) {
                unitField("kg", value: $kg, format: "%.1f") {
                    lbs = kg * 2.20462
                }
                arrowLabel("↔")
                unitField("lbs", value: $lbs, format: "%.1f") {
                    kg = lbs / 2.20462
                }
            }
        }
    }
}

// MARK: - Pressure Converter

struct PressureConverterCard: View {
    @EnvironmentObject var theme: ThemeManager
    @State private var mmHg: Double = 120.0
    @State private var cmH2O: Double = 163.2
    @State private var kPa: Double = 16.0

    var body: some View {
        converterCard(title: "Pressure", icon: "gauge.medium", colorKey: "section7") {
            VStack(spacing: 10) {
                sectionHeader("mmHg  ↔  cmH₂O  ↔  kPa")
                HStack(spacing: 8) {
                    unitField("mmHg", value: $mmHg, format: "%.1f") {
                        cmH2O = mmHg * 1.35951
                        kPa   = mmHg * 0.133322
                    }
                    arrowLabel("↔")
                    unitField("cmH₂O", value: $cmH2O, format: "%.1f") {
                        mmHg = cmH2O / 1.35951
                        kPa  = mmHg * 0.133322
                    }
                    arrowLabel("↔")
                    unitField("kPa", value: $kPa, format: "%.2f") {
                        mmHg  = kPa / 0.133322
                        cmH2O = mmHg * 1.35951
                    }
                }
            }
        }
    }
}

// MARK: - Shared helpers (file-private)

private func converterCard<Content: View>(
    title: String, icon: String, colorKey: String,
    @escaping @ViewBuilder content: () -> Content
) -> some View {
    _ConverterCard(title: title, icon: icon, colorKey: colorKey, content: content)
}

private struct _ConverterCard<Content: View>: View {
    let title: String
    let icon: String
    let colorKey: String
    @ViewBuilder let content: () -> Content
    @EnvironmentObject var theme: ThemeManager

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(width: 26, height: 26)
                    .background(Color.white.opacity(0.2))
                    .clipShape(RoundedRectangle(cornerRadius: 6))
                Text(title.uppercased())
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(.white)
                    .tracking(0.5)
                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(theme.sectionColor(colorKey))

            VStack(alignment: .leading, spacing: 10) {
                content()
            }
            .padding(14)
            .background(Color(.systemBackground))
        }
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .shadow(color: .black.opacity(0.07), radius: 3, y: 2)
    }
}

private func sectionHeader(_ text: String) -> some View {
    Text(text)
        .font(.system(size: 10, weight: .semibold))
        .foregroundColor(.secondary)
        .tracking(0.3)
        .frame(maxWidth: .infinity, alignment: .leading)
}

private func arrowLabel(_ symbol: String) -> some View {
    Text(symbol)
        .font(.system(size: 15, weight: .medium))
        .foregroundColor(.secondary)
        .frame(width: 24)
}

private func unitField(
    _ label: String,
    value: Binding<Double>,
    format: String,
    onChange: @escaping () -> Void
) -> some View {
    _UnitField(label: label, value: value, format: format, onChange: onChange)
}

private struct _UnitField: View {
    let label: String
    @Binding var value: Double
    let format: String
    let onChange: () -> Void
    @EnvironmentObject var theme: ThemeManager

    var body: some View {
        VStack(alignment: .center, spacing: 3) {
            Text(label)
                .font(.system(size: 9, weight: .medium))
                .foregroundColor(.secondary)
            TextField("", value: $value, format: .number)
                .keyboardType(.decimalPad)
                .multilineTextAlignment(.center)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(theme.secondary)
                .padding(.vertical, 6)
                .padding(.horizontal, 4)
                .background(Color(.systemBackground))
                .cornerRadius(6)
                .overlay(RoundedRectangle(cornerRadius: 6)
                    .stroke(theme.secondary.opacity(0.3), lineWidth: 1))
                .onChange(of: value) { _ in onChange() }
        }
        .frame(maxWidth: .infinity)
    }
}
